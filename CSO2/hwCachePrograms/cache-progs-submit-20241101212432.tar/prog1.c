#include <stdio.h>

#pragma GCC optimize (2, "no-tree-vectorize")

int global_array[1048568] __attribute__((aligned(128)));

void prevent_optimizations_based_on_knowing_array_values() {
    __asm__ volatile ("":::"memory");
}

int main() {
    const int MAX = 8100;
    const int SKIP = 16;  // Preserve locality to help the 32KB cache
    const int ITERS = 64000000;  // Reduced for faster runtime with larger array

#pragma clang loop vectorize(disable)
#pragma clang loop interleave(disable)

    for (int i = 0; i < MAX; ++i) {
        global_array[i] = (i + SKIP) % MAX;
    }
    prevent_optimizations_based_on_knowing_array_values();
    int j = 0;

#pragma clang loop vectorize(disable)
#pragma clang loop interleave(disable)

    for (int i = 0; i < ITERS; ++i) {
        j = global_array[j];
    }
    
    printf("%d\n", j);
}

