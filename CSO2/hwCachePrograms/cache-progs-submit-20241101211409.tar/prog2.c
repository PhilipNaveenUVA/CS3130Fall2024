#include <stdio.h>


#include <stdio.h>
#pragma GCC optimize (2, "no-tree-vectorize")

int global_array[1048568] __attribute__((aligned(128)));

void prevent_optimizations_based_on_knowing_array_values() {
    __asm__ volatile ("":::"memory");
}

int main() {


        const int MAX = 65536;

    const int SKIP = 16384;

    const int ITERS =  5000000;

	
#pragma clang loop vectorize(disable)
#pragma clang loop interleave(disable)
    for (int i = 0; i < MAX; ++i) {
        global_array[i] = (i + SKIP) % MAX;
    }

    prevent_optimizations_based_on_knowing_array_values();
    int j = 0;

#pragma clang loop vectorize(disable)
#pragma clang loop interleave(disable)
    for (int i = 0; i < ITERS; ++i) {
        j = global_array[j];
    }

    printf("%d\n", j);
}

